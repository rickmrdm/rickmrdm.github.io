#include <memory>
#include <WiFiClientSecureBearSSL.h>
#include <ESP8266HTTPClient.h>
#include "util.hpp"
#include "ResInt.hpp"
#include "proxyRecuperaSalida.hpp"

ResInt proxyRecuperaSalida(
  const char *huellaDigital,
  const char * dispostivo) {
  String error;
  int valor = 0;
  String URL(URL_SALIDA);
  URL += dispostivo;

  std::unique_ptr <
  BearSSL::WiFiClientSecure
  > clie(
    new BearSSL::
    WiFiClientSecure);
  clie->setFingerprint(
    huellaDigital);

  HTTPClient http;
  Serial.print("Conectando ");
  Serial.println(
    "al servidor...");
  if (http.begin(*clie, URL)) {
    Serial.println(
      "Inicia GET...");
    int cod = http.GET();
    if (cod > 0) {
      String texto =
        http.getString();
      Serial.printf(
        "Código de GET: %d\n",
        cod);
      Serial.println(texto);
      switch (cod) {
        case HTTP_CODE_OK:
        case
            HTTP_CODE_MOVED_PERMANENTLY:
          valor = atoi(
                    texto.c_str());
          break;
        default:
          error = texto;
      }
    } else {
      error =
        http.errorToString(cod);
    }
    http.end();
  } else {
    error = "La conexión falló";
  }
  Serial.printf("valor: %d\n",
                valor);
  return ResInt(valor, error);
}
