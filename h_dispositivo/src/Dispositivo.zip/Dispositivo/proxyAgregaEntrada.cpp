#include <memory>
#include <WiFiClientSecureBearSSL.h>
#include <ESP8266HTTPClient.h>
#include "util.hpp"
#include "proxyAgregaEntrada.hpp"


String
proxyAgregaEntrada(
  const char* huellaDigital,
  const char * dispostivo,
  int valor) {
  String error;
  String txt(valor);
  String URL(URL_ENTRADA);
  URL += dispostivo;

  Serial.printf(
    "Enviando: %s\n",
    txt.c_str());

  std::unique_ptr <
  BearSSL::WiFiClientSecure
  > clie(
    new BearSSL::
    WiFiClientSecure);
  clie->setFingerprint(
    huellaDigital);

  HTTPClient http;
  Serial.print("Conectando ");
  Serial.println(
    "al servidor...");
  if (http.begin(*clie, URL)) {
    Serial.print(
      "Inicia POST...\n");
    http.addHeader("Content-Type",
                   "text/plain");
    int cod = http.POST(txt);
    if (cod > 0) {
      String texto =
        http.getString();
      Serial.printf(
        "Código de POST: %d\n",
        cod);
      Serial.println(texto);
      switch (cod) {
        case HTTP_CODE_OK:
        case
            HTTP_CODE_MOVED_PERMANENTLY:
          break;
        default:
          error = texto;
      }
    } else {
      error =
        http.errorToString(cod);
    }
    http.end();
  } else {
    error = "La conexión falló";
  }
  return error;
}
